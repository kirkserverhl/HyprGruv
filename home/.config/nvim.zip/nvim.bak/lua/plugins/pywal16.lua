return {
  {
    'uZer/pywal16.nvim',
    config = function()
      vim.cmd.colorscheme("pywal16")
    end,
  },
}
